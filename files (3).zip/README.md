# 7006SCN Machine Learning and Big Data

Predicting whether a NYC yellow taxi passenger paid by cash or by card, using PySpark.

- **Student:** Sridhar Gude (SID 17165640)
- **Dataset:** NYC TLC Yellow Taxi Trip Records, Jan-Jun 2024 (Dataset Catalogue No. 33)
- **Source:** https://www.nyc.gov/site/tlc/about/tlc-trip-record-data.page

## Structure
- `notebooks/Task1.ipynb` problem, data and pipeline
- `notebooks/Task2.ipynb` modelling at scale (to come)
- `notebooks/Task3.ipynb` evaluation, optimisation, explainability (to come)
- `notebooks/Task4.ipynb` Tableau export and reflection (to come)
- `results/task1.json` ... `task4.json`

## How to run
1. Python 3.10+, Java 17, `pip install pyspark`.
2. Open `notebooks/Task1.ipynb` and run all cells from the top. The raw Parquet files download into `data/raw` (not committed).

## Status
- [x] Task 1
- [ ] Task 2
- [ ] Task 3
- [ ] Task 4
