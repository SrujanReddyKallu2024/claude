# =====================================================================
# TASK 1 - WEEK 2 CELLS
# Add these at the END of Task1.ipynb (after the EP1 cell), one block per cell.
# Each "CELL" block below = one new cell in Kaggle. Run them in order.
# Needs the variables from Week 1 (train, clean, prep_model, num_cols, task1, RES_DIR, OUT_DIR).
# =====================================================================


# ---------------------------------------------------------------------
# CELL 1 (Markdown)   paste this text as a Markdown cell
# ---------------------------------------------------------------------
# ## 12. Week 2: partitioning, sampling and dimensionality
# **Fig. T1.8** partition sizes and a 5% stratified sample check
# **Fig. T1.9** PCA on the 14 numeric columns
# **Fig. T1.10** cash share by month


# ---------------------------------------------------------------------
# CELL 2 (Code)   Fig. T1.8  partition sizes + sample check
# ---------------------------------------------------------------------
from pyspark.sql.functions import spark_partition_id

# (a) are the training partitions even? (skew check)
part_stats = (train.groupBy(spark_partition_id().alias("pid")).count()
                   .agg(F.count("*").alias("partitions"),
                        F.min("count").alias("min_rows"),
                        F.max("count").alias("max_rows"),
                        F.round(F.avg("count")).alias("avg_rows"))
                   .first().asDict())
part_stats["max_to_avg"] = round(part_stats["max_rows"] / part_stats["avg_rows"], 2)
print("training partitions:", part_stats)

# (b) 5% stratified sample, to make tuning in Task 2 faster
SAMPLE_FRACTION = 0.05
sample = train.sampleBy("is_cash", fractions={0: SAMPLE_FRACTION, 1: SAMPLE_FRACTION}, seed=42)

def profile(df):
    return (df.agg(F.count("*").alias("rows"),
                   F.round(F.avg("is_cash") * 100, 2).alias("cash_pct"),
                   F.round(F.avg("trip_distance"), 3).alias("avg_distance"),
                   F.round(F.avg("fare_amount"), 3).alias("avg_fare"))
              .first().asDict())

full_profile, sample_profile = profile(train), profile(sample)
print("full training set :", full_profile)
print("5% sample         :", sample_profile)

sample.write.mode("overwrite").parquet(os.path.join(OUT_DIR, "train_sample.parquet"))
print("sample saved for Task 2")


# ---------------------------------------------------------------------
# CELL 3 (Code)   Fig. T1.9  PCA check on the numeric columns
# ---------------------------------------------------------------------
from pyspark.ml.feature import PCA

pca_in = prep_model.transform(sample).select("num_scaled")
pca_model = PCA(k=len(num_cols), inputCol="num_scaled", outputCol="pca_out").fit(pca_in)

explained = [float(x) for x in pca_model.explainedVariance.toArray()]
cumulative, running = [], 0.0
for v in explained:
    running += v
    cumulative.append(round(running, 4))

k95 = next(i + 1 for i, c in enumerate(cumulative) if c >= 0.95)
for i, (v, c) in enumerate(zip(explained, cumulative), 1):
    print(f"component {i:2d}: {v*100:5.2f}%   cumulative {c*100:6.2f}%")
print(f"\n{k95} of {len(num_cols)} components are needed for 95% of the variance")


# ---------------------------------------------------------------------
# CELL 4 (Code)   Fig. T1.10  cash share by month (drift check)
# ---------------------------------------------------------------------
by_month = (clean.groupBy(F.month("tpep_pickup_datetime").alias("month"))
                 .agg(F.count("*").alias("trips"),
                      F.round(F.avg("is_cash") * 100, 2).alias("cash_pct"))
                 .orderBy("month"))
by_month.show()
month_rows = [r.asDict() for r in by_month.collect()]


# ---------------------------------------------------------------------
# CELL 5 (Code)   add the Week 2 results to results/task1.json
# ---------------------------------------------------------------------
with open(os.path.join(RES_DIR, "task1.json")) as fh:
    task1 = json.load(fh)

task1["week2"] = {
    "training_partition_stats": part_stats,
    "sample_fraction": SAMPLE_FRACTION,
    "full_training_profile": full_profile,
    "sample_profile": sample_profile,
    "pca_components_for_95pct": k95,
    "pca_numeric_columns": len(num_cols),
    "pca_cumulative_variance": cumulative,
    "cash_share_by_month": month_rows,
}
with open(os.path.join(RES_DIR, "task1.json"), "w") as fh:
    json.dump(task1, fh, indent=2)
print("task1.json updated with week2 results")
